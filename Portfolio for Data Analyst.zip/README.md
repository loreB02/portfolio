
  # Portfolio for Data Analyst

  This is a code bundle for Portfolio for Data Analyst. The original project is available at https://www.figma.com/design/KRNRAn4feMTXDj8ghAj6kn/Portfolio-for-Data-Analyst.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  